#ifndef __SYSCALL_H
#define __SYSCALL_H

int syscall_init(void);
int syscall_exit(void);

#endif
